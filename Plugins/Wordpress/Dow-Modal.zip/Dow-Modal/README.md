# Dow Modal - Wordpress Plugin
This wordpress plugin is designed for the google translotor.  We needed to display text before choosing the language you wanted to switch over to.

It does require the Google Traslator Plugin to be installed and activated first.

This is still a work in progress as I am updating some features.  Currenting it allows you to only add four papagraphs and the link to the google translator is hard coded in.  The goal is to make it more dynamic and allow the user to add the shortcode they wish.